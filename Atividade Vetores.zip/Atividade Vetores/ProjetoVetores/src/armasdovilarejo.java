import javax.swing.JOptionPane;
public class armasdovilarejo {
    public static void main(String[] args) {
        String [] armasdaloja = {"Adaga de bronze ", "Arco curto", "Espada longa", "Cajado mágico"};
        JOptionPane.showMessageDialog(null, "Item promocional do dia: " + armasdaloja[3]);
    }
}
