public class DesafioHP {
    public static void main(String[] args) {
        String [] Hpdoschefes = {"150", "500", "2500"};
        System.out.println("Atenção!!! O Chefão final está com: " + Hpdoschefes[2]);
    }
}
