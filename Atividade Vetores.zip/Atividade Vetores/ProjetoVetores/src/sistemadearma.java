public class sistemadearma {
    public static void main(String[] args) {
        String [] armamento = {"Adaga de bronze ", "Arco curto", "Espada longa", "Cajado mágico"};
        System.out.println("Voce escolheu o item promocional do dia: " + armamento [3]);

    }
}
