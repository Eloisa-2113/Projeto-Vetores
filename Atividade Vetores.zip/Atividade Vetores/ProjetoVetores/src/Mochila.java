public class Mochila {
    public static void main(String[] args) {
        String [] mochila = {"Espada ⚔️", "Escudo 🛡️", "Poção da vida 🧬", "Maçã 🍎"};
        System.out.println(" Você escolheu o item " + mochila [1]);
    }
}
