import javax.swing.JOptionPane;
public class Novamochila {
    public static void main(String[] args) {
        String[] mochila = new String[3]; // Cria espaço para 3 itens

        mochila[0] = JOptionPane.showInputDialog("Item 1 da Mochila:");
        mochila[1] = JOptionPane.showInputDialog("Item 2 da Mochila:");
        mochila[2] = JOptionPane.showInputDialog("Item 3 da Mochila:");
        JOptionPane.showMessageDialog(null, "--- MOCHILA ---\n" +
                "Slot 0: " + mochila[0] + "\n" +
                "Slot 1: " + mochila[1] + "\n" +
                "Slot 2: " + mochila[2]);

        int[] danos = new int[3]; // Cria espaço para 3 números de dano

        // Recebe o texto da caixinha e converte para número inteiro (int)
        danos[0] = Integer.parseInt(JOptionPane.showInputDialog("Dano do Ataque 1:"));
        danos[1] = Integer.parseInt(JOptionPane.showInputDialog("Dano do Ataque 2:"));
        danos[2] = Integer.parseInt(JOptionPane.showInputDialog("Dano do Ataque 3:"));

        double mediaDano = (danos[0] + danos[1] + danos[2]) / 3.0;
        JOptionPane.showMessageDialog(null, "Média de dano dos golpes: " + mediaDano);


        String[] loginSistema = {"guerreiro123", "senha123"};

        String usuarioDigitado = JOptionPane.showInputDialog("Login - Digite o Usuário:");
        String senhaDigitada = JOptionPane.showInputDialog("Login - Digite a Senha:");

        if (usuarioDigitado.equals(loginSistema[0]) && senhaDigitada.equals(loginSistema[1])) {
            JOptionPane.showMessageDialog(null, "Acesso Permitido!");
        } else {
            JOptionPane.showMessageDialog(null, "Acesso Negado!");
        }

        double[] precos = {15.00, 25.00};

        int opcao = Integer.parseInt(JOptionPane.showInputDialog("Escolha a poção:\n0 - Vida (R$15)\n1 - Mana (R$25)"));
        double dinheiro = Double.parseDouble(JOptionPane.showInputDialog("Quanto dinheiro você vai dar?"));

        double precoSelecionado = precos[opcao];
        double troco = dinheiro - precoSelecionado;

        JOptionPane.showMessageDialog(null, "Troco calculado com base no array: R$ " + troco);
    }
}

